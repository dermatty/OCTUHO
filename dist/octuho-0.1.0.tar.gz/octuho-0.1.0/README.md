OCTUHO - OpnSense CSV To Unbound HostOverrides

Replaces OpnSense Host Overrides by the content of a CSV file - ideally following the KEA export csv file format, 
so KEA exports can be directly used.

Create a directory "octuho" in your linux home directory and place the file "/home/myuser/octuho/octuho.config" (example 
see data directory here) here: 

    url: OpnSense Url
    api_key: OpnSense API Key
    api_secret: OpnSense API Secret
    domain: Domain (the "Domain" entry from System > Settings > General)

Parameter: csv_file_path

Install: install 



